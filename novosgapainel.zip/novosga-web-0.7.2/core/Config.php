<?php
namespace core;
/* Arquivo de configuracao inicial */
class Config {
    const IS_DEV = true;
    const SGA_INSTALLED = false;
}
